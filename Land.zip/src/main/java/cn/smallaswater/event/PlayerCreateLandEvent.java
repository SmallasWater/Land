package cn.smallaswater.event;

import cn.nukkit.Player;
import cn.nukkit.event.HandlerList;
import cn.nukkit.event.player.PlayerEvent;
import cn.smallaswater.land.utils.LandData;

public class PlayerCreateLandEvent extends PlayerEvent {
    private static final HandlerList HANDLERS = new HandlerList();

    public static HandlerList getHandlers() {
        return HANDLERS;
    }

    private LandData data;
    public PlayerCreateLandEvent(Player player, LandData data){
        this.player = player;
        this.data = data;
    }

    public LandData getData() {
        return data;
    }
}
