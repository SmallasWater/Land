package cn.smallaswater.event;

public class PlayerQuitLandEvent {
}
