package cn.smallaswater.event;

public class PlayerJoinLandEvent {
}
