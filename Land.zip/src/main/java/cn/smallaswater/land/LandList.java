package cn.smallaswater.land;

import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.utils.DataTool;

import java.util.LinkedHashMap;
import java.util.LinkedList;

/**
 * @author 若水
 */
public class LandList extends LinkedList{

    private LinkedList<LandData> data;

    public LandList(LinkedList<LandData> data){
        this.data = data;
    }


    public LinkedList<LinkedHashMap<String,Object>> getConfig(){
        LinkedList<LinkedHashMap<String,Object>> config = new LinkedList<>();
        LinkedHashMap<String,Object> obj;
        for(LandData data:data){
            obj = new LinkedHashMap<>();
            obj.put("landName",data.getLandName());
            obj.put("master",data.getMaster());
            obj.put("vector",data.getVector().getConfig());
            obj.put("member",data.getMember().getMember());
            obj.put("defaultSetting",data.getDefaultSetting().getSettings());
            obj.put("joinMessage",data.getJoinMessage());
            obj.put("quitMessage",data.getQuitMessage());
            obj.put("transfer", DataTool.getMapByTransfer(data.getTransfer()));
            config.add(obj);
        }
        return config;
    }


    public LandData getLandDataByName(String name){

        for(LandData data:data){
            if(data.getLandName().equalsIgnoreCase(name)){
                return data;
            }
        }
        return null;
    }

    public LinkedList<LandData> getData() {
        return data;
    }

    public void add(LandData data){
        if(!contains(data)) {
            this.data.add(data);
        }
    }

    public void remove(LandData data){
        this.data.remove(data);
    }

    public boolean contains(LandData data){
        return this.data.contains(data);
    }


}
