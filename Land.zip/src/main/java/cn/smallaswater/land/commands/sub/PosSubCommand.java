package cn.smallaswater.land.commands.sub;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParameter;
import cn.nukkit.level.Position;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.utils.DataTool;
import cn.smallaswater.utils.Language;
import cn.smallaswater.utils.Vector;
import top.wetabq.easyapi.command.EasySubCommand;

import java.util.LinkedList;


public class PosSubCommand extends EasySubCommand {


    public PosSubCommand(String subCommandName) {
        super(subCommandName);
    }

    @Override
    public boolean execute(CommandSender sender, String s, String[] strings) {
        if(sender instanceof Player) {
            if (strings.length > 1) {
                Language language = LandModule.getModule().getLanguage();
                LinkedList<Position> positions = new LinkedList<>();
                if ("1".equalsIgnoreCase(strings[1])) {
                    LandModule.getModule().pos.put(sender.getName(), positions);
                    Position position = new Position(((Player) sender).getFloorX(), ((Player) sender).getFloorY()
                            ,((Player) sender).getFloorZ(),((Player) sender).getLevel());
                    positions.add(position);
                    sender.sendMessage(language.playerSetPos1.replace("%pos%",getPos(position)));
                    return true;
                }else if("2".equalsIgnoreCase(strings[1])){
                    if(!LandModule.getModule().pos.containsKey(sender.getName())){
                        sender.sendMessage(language.playerSetPos2Error);
                        return false;
                    }
                    Position position = new Position(((Player) sender).getFloorX(), ((Player) sender).getFloorY()
                            ,((Player) sender).getFloorZ(),((Player) sender).getLevel());
                    positions = LandModule.getModule().pos.get(sender.getName());
                    Position position1 = positions.get(0);
                    if(position1.getLevel().getFolderName().equalsIgnoreCase(((Player) sender).getLevel().getFolderName())){
                        positions.add(position);
                        LandModule.getModule().pos.put(sender.getName(),positions);
                        sender.sendMessage(language.playerSetPos2.replace("%pos%",getPos(position)).replace("%money%",
                                String.format("%.2f", DataTool.getLandMoney(new Vector(positions.get(0),position)))));
                        return true;
                    }else{
                        LandModule.getModule().pos.remove(sender.getName());
                        sender.sendMessage(language.playerSetPos2ErrorLevel);
                    }
                }
            }
        }
        return false;
    }

    @Override
    public String[] getAliases() {
        return new String[0];
    }

    @Override
    public String getDescription() {
        return "设置领地范围";
    }

    @Override
    public CommandParameter[] getParameters() {
        return new CommandParameter[]{
                new CommandParameter("value",new String[]{"1","2"})
        };
    }

    private String getPos(Position position){
        return LandModule.getModule().getLanguage().position
                .replace("%x%",position.getFloorX()+"")
                .replace("%y%",position.getFloorY()+"")
                .replace("%z%",position.getFloorZ()+"")
                .replace("%level%",position.getLevel().getFolderName()+"");
    }
}
