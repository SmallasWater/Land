package cn.smallaswater.land.commands.sub;

import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import cn.smallaswater.land.commands.LandCommand;
import cn.smallaswater.land.utils.InviteHandle;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.utils.Language;
import top.wetabq.easyapi.command.EasySubCommand;

import java.util.LinkedList;

/**
 * @author 若水
 */
public class AcceptSubCommand extends EasySubCommand {
    public AcceptSubCommand(String subCommandName) {
        super(subCommandName);
    }

    @Override
    public boolean execute(CommandSender commandSender, String s, String[] strings) {
        Language language = LandModule.getModule().getLanguage();
        if(commandSender instanceof Player){
            if(strings.length > 1) {
                String target = strings[1];
                LinkedList<InviteHandle> handles = LandModule.getModule().inviteLands.get(commandSender.getName());
                InviteHandle handle = LandCommand.getInviteHandle((Player) commandSender,target);
                if (handles != null) {
                    if(handle != null){
                        handle.accept();
                    }else{
                        commandSender.sendMessage(language.notHaveTargetInvite.replace("%p%",target));
                    }
                }else{
                    commandSender.sendMessage(language.notHaveInvite);
                }
            }

        }
        return false;
    }

    @Override
    public String[] getAliases() {
        return new String[0];
    }

    @Override
    public String getDescription() {
        return "接受邀请领地";
    }

    @Override
    public CommandParameter[] getParameters() {
        return new CommandParameter[]{
                new CommandParameter("player", CommandParamType.TARGET,true)};
    }
}
