package cn.smallaswater.land.commands;


import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.command.CommandSender;
import cn.smallaswater.land.commands.sub.*;
import cn.smallaswater.land.utils.InviteHandle;
import cn.smallaswater.module.LandModule;
import top.wetabq.easyapi.command.EasyCommand;

import java.util.LinkedList;

/**
 * @author 若水
 */
public class LandCommand extends EasyCommand {
    public LandCommand(String command, String description) {
        super(command, description);
        this.setPermission("Land.land");
        this.getSubCommand().add(new AllSubCommand("all"));
        this.getSubCommand().add(new CreateSubCommand("create"));
        this.getSubCommand().add(new MySubCommand("my"));
        this.getSubCommand().add(new PosSubCommand("pos"));
        this.getSubCommand().add(new AcceptSubCommand("accept"));
        this.getSubCommand().add(new DenySubCommand("deny"));
        this.getSubCommand().add(new InvitesSubCommand("invites"));

    }
    @Override
    public void sendHelp(CommandSender sender) {
        sender.sendMessage("§e>>§a-------------------§bHelps of Land§a-------------------§e<<");
        sender.sendMessage("§e/land §7help §a查看插件帮助");
        sender.sendMessage("§e/land §7my§a显示自己的领地列表");
        sender.sendMessage("§e/land §7all 显示所有领地列表");
        sender.sendMessage("§e/land §7pos <1/2> §a设置领地坐标");
        sender.sendMessage("§e/land §7create <name> §a创建领地 p.s每个方块: $"+ String.format("%2f",LandModule.getModule().getConfig().getLandMoney()));
        sender.sendMessage("§e/land §7accept <player> §a同意该玩家的领地邀请");
        sender.sendMessage("§e/land §7deny <player> §a拒绝玩家的领地邀请");
        sender.sendMessage("§e/land §7invites §a查看邀请列表");
        sender.sendMessage("§e>>§a-------------------§bHelps of Land§a-------------------§e<<");
    }

    @Override
    public boolean execute( CommandSender sender,  String label,  String[] args) {
        return super.execute(sender,label,args);
    }

    public static InviteHandle getInviteHandle(Player player,String name){
        Player target = Server.getInstance().getPlayer(name);
        if(player != null){
            name = player.getName();
        }
        LinkedList<InviteHandle> handles = LandModule.getModule().inviteLands.get(player.getName());
        InviteHandle handle = null;
        if (handles != null) {
            for (InviteHandle handle1 : handles) {
                if (handle1.getMaster().equalsIgnoreCase(name)) {
                    handle = handle1;
                }
            }
        }
        return handle;
    }
}
