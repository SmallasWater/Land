package cn.smallaswater.land.commands.sub;

import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.command.CommandSender;
import cn.nukkit.command.data.CommandParamType;
import cn.nukkit.command.data.CommandParameter;
import cn.nukkit.level.Position;
import cn.smallaswater.event.PlayerCreateLandEvent;
import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.players.MemberSetting;
import cn.smallaswater.players.PlayerSetting;
import cn.smallaswater.utils.DataTool;
import cn.smallaswater.utils.Language;
import cn.smallaswater.utils.Vector;
import top.wetabq.easyapi.command.EasySubCommand;

import java.util.LinkedHashMap;
import java.util.LinkedList;

/**
 * @author 若水
 */
public class CreateSubCommand extends EasySubCommand {
    public CreateSubCommand(String subCommandName) {
        super(subCommandName);
    }

    @Override
    public boolean execute(CommandSender sender, String s, String[] strings) {
        Language language = LandModule.getModule().getLanguage();
        if(sender instanceof Player) {
            if (strings.length > 1) {
                String name = strings[1];
                if(LandModule.getModule().pos.containsKey(sender.getName())){
                    LinkedList<Position> positions = LandModule.getModule().pos.get(sender.getName());
                    if(positions.size() > 1){
                        String landName = DataTool.checkOverlap(new Vector(positions.get(0),positions.get(1)));
                        if(landName != null){
                            sender.sendMessage(language.playerBuyLandErrorLandInArray.replace("%name%",landName));
                            LandModule.getModule().pos.remove(sender.getName());
                        }else{
                            if(LandModule.getModule().getList().getLandDataByName(name)!= null){
                                sender.sendMessage(language.playerBuyLandErrorLandExists.replace("%name%",name));
                                return true;
                            }else{
                                double money = DataTool.getLandMoney(new Vector(positions.get(0),positions.get(1)));
                                if(LandModule.getModule().getMoney().myMoney(sender.getName()) >= money){
                                    if(LandModule.getModule().getList().getData().size() >= LandModule.getModule().getConfig().getMaxLand()){
                                        LandModule.getModule().pos.remove(sender.getName());
                                        sender.sendMessage(language.playerLandMax.replace("%count%",LandModule.getModule().getConfig().getMaxLand()+""));
                                        return true;
                                    }else {
                                        LandModule.getModule().getMoney().reduceMoney(sender.getName(), money);
                                        Vector vector = new Vector(positions.get(0), positions.get(1));
                                        LandData data = new LandData(name, sender.getName(), vector
                                                , new MemberSetting(new LinkedHashMap<>()),
                                                PlayerSetting.getDefaultSetting(), language.playerJoinMessage, language.playerQuitMessage, DataTool.getDefaultPosition(vector));
                                        LandModule.getModule().getList().add(data);
                                        LandModule.getModule().saveList();
//                                        if(landList != null && playerConfig != null){
//                                            playerConfig.set("lands",landList.getConfig());
//                                            playerConfig.save();
//                                        }
                                        sender.sendMessage(language.playerBuyLandSuccess.replace("%name%", name).replace("%money%", money + ""));
                                        LandModule.getModule().pos.remove(sender.getName());
                                        PlayerCreateLandEvent event = new PlayerCreateLandEvent((Player) sender, data);
                                        Server.getInstance().getPluginManager().callEvent(event);
                                        return true;
                                    }
                                }else{
                                    sender.sendMessage(language.playerBuyLandError.replace("%money%",money+""));
                                    LandModule.getModule().pos.remove(sender.getName());
                                    return true;
                                }
                            }
                        }
                    }else{
                        sender.sendMessage(language.createNotHavePos2);
                    }
                }else{
                    sender.sendMessage(language.createNotHavePos);
                }

            }
        }
        return false;
    }

    @Override
    public String[] getAliases() {
        return new String[0];
    }

    @Override
    public String getDescription() {
        return "创建领地";
    }

    @Override
    public CommandParameter[] getParameters() {
        return new CommandParameter[]{
                new CommandParameter("name", CommandParamType.TEXT,true)
        };
    }
}
