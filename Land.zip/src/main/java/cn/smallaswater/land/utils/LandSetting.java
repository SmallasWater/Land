package cn.smallaswater.land.utils;





import java.util.LinkedHashMap;

/**
 * @author 若水
 */
public class LandSetting {
    private LinkedHashMap<Setting,Boolean> settings = new LinkedHashMap<>();

    public enum Setting{
        /**岩浆/水流动 TNT爆炸，作物生长 */
        WATER("水流动"),TNT("TNT爆炸"),BLOCK_UP_DATA("作物生长");

        protected String name;
        Setting(String name){
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public LandSetting(){
        for(Setting setting:Setting.values()){
            settings.put(setting,true);
        }
    }

    public boolean getSetting(Setting setting){
        if(settings.containsKey(setting)) {
            return settings.get(setting);
        }
        return true;
    }

    public void setSetting(Setting setting, boolean value) {
        this.settings.put(setting,value);
    }

}
