package cn.smallaswater.land.utils;

import java.util.LinkedList;

/**
 * @author 若水
 */
public class LandConfig {

    private String title;

    private double landMoney;

    private int sellMoney;

    private LinkedList<String> whiteList;

    private int maxLand;

    private int time;



    public LandConfig(String title,double landMoney,int sellMoney,LinkedList<String> whiteList,int maxLand,int time){
        this.landMoney = landMoney;
        this.whiteList = whiteList;
        this.maxLand = maxLand;
        this.time = time;
        this.title = title;
        this.sellMoney = sellMoney;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public int getSellMoney() {
        return sellMoney;
    }

    public void setSellMoney(int sellMoney) {
        this.sellMoney = sellMoney;
    }

    public double getLandMoney() {
        return landMoney;
    }

    public LinkedList<String> getWhiteList() {
        return whiteList;
    }

    public int getMaxLand() {
        return maxLand;
    }

    public void setLandMoney(double landMoney) {
        this.landMoney = landMoney;
    }

    public void setMaxLand(int maxLand) {
        this.maxLand = maxLand;
    }

    public void setWhiteList(LinkedList<String> whiteList) {
        this.whiteList = whiteList;
    }
}
