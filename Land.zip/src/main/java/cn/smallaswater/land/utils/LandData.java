package cn.smallaswater.land.utils;


import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.level.Position;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.players.LandSetting;
import cn.smallaswater.players.MemberSetting;
import cn.smallaswater.players.PlayerSetting;
import cn.smallaswater.utils.Vector;

import java.util.LinkedHashMap;


/**
 * @author 若水
 */
public class LandData  {

    private String landName;

    private String master;

    private Vector vector;

    private MemberSetting member;

    private PlayerSetting defaultSetting;

    private String joinMessage;

    private String quitMessage;

    private Position transfer;

    public LandData(String landName,String master,Vector vector,
                    MemberSetting member,
                    PlayerSetting defaultSetting,
                    String joinMessage,String quitMessage,Position transfer){
        this.landName = landName;
        this.master = master;
       this.vector = vector;
        this.member = member;
        this.defaultSetting = defaultSetting;
        this.joinMessage = joinMessage;
        this.quitMessage = quitMessage;
        this.transfer = transfer;
    }

    public Vector getVector() {
        return vector;
    }

    public Position getTransfer() {
        return transfer;
    }

    public void setQuitMessage(String quitMessage) {
        this.quitMessage = quitMessage;
    }

    public void setTransfer(Position transfer) {
        this.transfer = transfer;
    }

    public void setMaster(String master) {
        this.master = master;
    }

    public void setMember(MemberSetting member) {
        this.member = member;
    }

    public void setDefaultSetting(PlayerSetting defaultSetting) {
        this.defaultSetting = defaultSetting;
    }

    public void setDefaultSetting(String setting, boolean value){
        this.defaultSetting.setSetting(setting, value);
    }

    public void setJoinMessage(String joinMessage) {
        this.joinMessage = joinMessage;
    }

    public String getMaster() {
        return master;
    }

    public void addMember(String member){
        Player player = Server.getInstance().getPlayer(member);
        if(player != null){
            player.sendMessage(LandModule.getModule().getLanguage().playerJoinLandMessageTarget.replace("%p%",master).replace("%name%",landName));
        }
        player = Server.getInstance().getPlayer(master);
        if(player != null){
            player.sendMessage(LandModule.getModule().getLanguage().playerJoinLandMessageMaster.replace("%p%",member).replace("%name%",getLandName()));
        }
        this.member.put(member,PlayerSetting.getPlayerDefaultSetting());
    }

    public void setPlayerSetting(String player, LandSetting setting, boolean value){
        if(!member.containsKey(player)){
            member.put(player,PlayerSetting.getPlayerDefaultSetting());
        }
        PlayerSetting setting1 = member.get(player);
        setting1.setSetting(setting.getName(),value);
    }

    public void removeMember(String member){
        Player player = Server.getInstance().getPlayer(member);
        if(player != null){
            player.sendMessage(LandModule.getModule().getLanguage().playerQuitLandMessageTarget.replace("%p%",master).replace("%name%",landName));
        }
        player = Server.getInstance().getPlayer(master);
        if(player != null){
            player.sendMessage(LandModule.getModule().getLanguage().playerQuitLandMessageMaster.replace("%p%",member).replace("%name%",getLandName()));
        }
        this.member.remove(member);
    }

    public boolean hasPermission(String player, LandSetting setting){
        if(player != null) {
            Player player1 = Server.getInstance().getPlayer(player);
            if (player1 != null) {
                if (player1.isOp()) {
                    return true;
                }
            }
            if (master.equalsIgnoreCase(player)) {
                return true;
            } else if (member.containsKey(player)) {
                PlayerSetting setting1 = member.get(player);
                return setting1.getSetting(setting.getName());
            }
        }
        return defaultSetting.getSetting(setting.getName());
    }


    public MemberSetting getMember() {
        return member;
    }

    public PlayerSetting getDefaultSetting() {
        return defaultSetting;
    }

    public String getJoinMessage() {
        return joinMessage;
    }

    public String getLandName() {
        return landName;
    }

    public String getQuitMessage() {
        return quitMessage;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof LandData){
            return ((LandData) obj).getLandName().equalsIgnoreCase(getLandName());
        }
        return false;
    }

}


