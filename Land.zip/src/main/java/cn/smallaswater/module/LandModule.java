package cn.smallaswater.module;

import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.block.BlockChest;
import cn.nukkit.entity.Entity;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.block.BlockBreakEvent;
import cn.nukkit.event.block.BlockPlaceEvent;
import cn.nukkit.event.entity.EntityDamageByEntityEvent;
import cn.nukkit.event.entity.EntityDamageEvent;
import cn.nukkit.event.player.*;
import cn.nukkit.level.Position;
import cn.nukkit.scheduler.PluginTask;
import cn.nukkit.utils.Config;
import cn.smallaswater.LandMainClass;
import cn.smallaswater.land.LandList;
import cn.smallaswater.land.commands.LandCommand;
import cn.smallaswater.land.utils.InviteHandle;
import cn.smallaswater.land.utils.LandConfig;
import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.players.LandSetting;
import cn.smallaswater.players.MemberSetting;
import cn.smallaswater.players.PlayerSetting;
import cn.smallaswater.utils.DataTool;
import cn.smallaswater.utils.Language;
import cn.smallaswater.utils.LoadMoney;
import cn.smallaswater.utils.Vector;
import cn.smallaswater.windows.WindowListener;
import top.wetabq.easyapi.api.defaults.CommandAPI;
import top.wetabq.easyapi.api.defaults.ConfigAPI;
import top.wetabq.easyapi.api.defaults.NukkitListenerAPI;
import top.wetabq.easyapi.api.defaults.PluginTaskAPI;
import top.wetabq.easyapi.config.encoder.advance.ReflectionConfigCodec;
import top.wetabq.easyapi.config.encoder.advance.SimpleCodecEasyConfig;
import top.wetabq.easyapi.module.ModuleInfo;
import top.wetabq.easyapi.module.ModuleVersion;
import top.wetabq.easyapi.module.SimpleEasyAPIModule;
import top.wetabq.easyapi.task.PluginTaskEntry;


import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author 若水
 */
public class LandModule extends SimpleEasyAPIModule {
    private static LandModule module;

    private SimpleCodecEasyConfig<LandConfig> config;

    public Config playerConfig;

    public LandList landList;

    private SimpleCodecEasyConfig<Language> languageConfig;

    private Language language;

    public LinkedHashMap<String, LinkedList<Position>> pos = new LinkedHashMap<>();

    private LoadMoney money;

    private LinkedHashMap<Player,String> move = new LinkedHashMap<>();

    public LinkedHashMap<Player,LandData> clickData = new LinkedHashMap<>();

    public LinkedHashMap<Player,String> clickPlayer = new LinkedHashMap<>();

    public LinkedHashMap<String,LinkedList<InviteHandle>> inviteLands = new LinkedHashMap<>();
    @Override
    public void moduleDisable() {
        if(config != null){
            config.save();
        }
        saveList();
        if(languageConfig != null){
            languageConfig.save();
        }
    }

    public void saveList(){
        if(landList != null && playerConfig != null){
            playerConfig.set("lands",landList.getConfig());
            playerConfig.save();
        }
    }

    @Override
    public void moduleRegister() {
        module = this;
        money = new LoadMoney();
        config = new SimpleCodecEasyConfig<LandConfig>("config", getModuleInfo().getModuleOwner(), LandConfig.class,new LandConfig("[领地系统]",10D,
                50,new LinkedList<>(),5,0), new ReflectionConfigCodec<>(LandConfig.class)) {};
        this.registerAPI("landConfig", new ConfigAPI()).add(config);
        playerConfig = new Config(getModuleInfo().getModuleOwner().getDataFolder()+"/LandData.yml",2);

//        playerData = new SimpleCodecEasyConfig<LandList>("landData",getModuleInfo().getModuleOwner(),LandList.class,
//                new LandList(new LinkedList<>()), new ReflectionConfigCodec<>(LandList.class)){
//            @Override
//            public LinkedHashMap<String, ?> encode(LandList obj) {
//                return new LinkedHashMap<String, Object>(){
//                    {
//                        put("lands",obj.getConfig());
//                    }
//                };
//            }
//
//            @Override
//            public LandList decode(LinkedHashMap<String, ?> map) {
//                LinkedList<LandData> data = new LinkedList<>();
//                List map1 = (List) map.get("lands");
//                for(Object o:map1){
//                    if(o instanceof Map){
//                        Map m = (Map) o;
//                        data.add(new LandData(
//                                m.get("landName").toString(),
//                                m.get("master").toString(),
//                                Vector.getVectorByMap((Map)m.get("vector")),
//                                new MemberSetting((Map)m.get("member")),
//                                new PlayerSetting((Map)m.get("defaultSetting")),
//                                m.get("joinMessage").toString(),
//                                m.get("quitMessage").toString(),
//                                DataTool.getPositionByMap((Map) m.get("transfer"))));
//                    }
//                }
//                return new LandList(data);
//            }
//        };
//        this.registerAPI("landDataConfig",new ConfigAPI()).add(playerData);

        languageConfig =  new SimpleCodecEasyConfig<Language>("language"
                ,getModuleInfo().getModuleOwner(),Language.class,new Language(),new ReflectionConfigCodec<>(Language.class)) {};

        this.registerAPI("landLanguage",new ConfigAPI()).add(languageConfig);
        this.language = languageConfig.getDefaultValue();
        this.registerAPI("landTask",new PluginTaskAPI<LandMainClass>(LandMainClass.MAIN_CLASS))
                .add(new PluginTaskEntry<>(new PluginTask<LandMainClass>(LandMainClass.MAIN_CLASS) {
                    @Override
                    public void onRun(int i) {
                        for(Player player: Server.getInstance().getOnlinePlayers().values()){
                            if(inviteLands.containsKey(player.getName())){
                                LinkedList<InviteHandle> handles = inviteLands.get(player.getName());
                                for(InviteHandle handle:handles){
                                    if(handle.getTime() > 0){
                                        handle.setTime(handle.getTime() - 1);
                                    }else{
                                        handle.timeOut();
                                    }
                                }
                            }
                        }
                    }
                },20,0));
        this.registerCommand();
        this.registerListener();
    }

    private void registerCommand(){
        this.registerAPI("landCommand",new CommandAPI()).add(new LandCommand("land","领地主命令"));
    }


    private void registerListener(){
        this.registerAPI("landListener",new NukkitListenerAPI(LandMainClass.MAIN_CLASS)).add(new Listener() {
            @EventHandler
            public void onMove(PlayerMoveEvent event){
                Player player = event.getPlayer();
                LandData data = DataTool.getPlayerLandData(player);
                if(data != null) {
                    if (hasPermission(player, event.getTo(), LandSetting.MOVE)) {
                        event.setCancelled();
                    } else {
                        if (!move.containsKey(player)) {
                            move.put(player, data.getLandName());
                            player.sendMessage(data.getJoinMessage()
                                    .replace("%n%", data.getLandName())
                                    .replace("%master%", data.getMaster())
                                    .replace("%member%", data.getMember().keySet().toString()));
                        }
                    }
                }else{
                    if(move.containsKey(player)){
                        data = LandModule.getModule().getList().getLandDataByName(move.get(player));
                        player.sendMessage(data.getQuitMessage()
                                .replace("%n%",data.getLandName())
                                .replace("%master%",data.getMaster())
                                .replace("%member%",data.getMember().keySet().toString()));
                        move.remove(player);
                    }
                }
            }
            @EventHandler
            public void onQuit(PlayerQuitEvent e){
                move.remove(e.getPlayer());
            }

            @EventHandler
            public void onPlayer(BlockPlaceEvent event){
                Player player = event.getPlayer();
                if(hasPermission(player, event.getBlock(),LandSetting.PLACE)){
                    event.setCancelled();
                }
            }
            @EventHandler
            public void onBreak(BlockBreakEvent event){
                Player player = event.getPlayer();
                if(hasPermission(player, event.getBlock(), LandSetting.BREAK)){
                    event.setCancelled();
                }
            }

            private boolean hasPermission(Player player, Position position, LandSetting setting){
                LandData data = DataTool.getPlayerLandData(position);
                if(data != null){
                     if(!data.hasPermission(player.getName(), setting)){
                         player.sendMessage(LandModule.getModule().getLanguage().notHavePermission
                                 .replace("%title%",LandModule.getModule().getConfig().getTitle()));
                         return true;
                     }
                }
                return false;
            }

            @EventHandler
            public void onUseChest(PlayerInteractEvent event){
                Player player = event.getPlayer();
                if(event.getBlock() instanceof BlockChest){
                   if(hasPermission(player, event.getBlock(), LandSetting.LOCK_CHEST)){
                       event.setCancelled();
                   }
                }
                if(event.getBlock().getId() == 61 || event.getBlock().getId() == 62){
                    if(hasPermission(player, event.getBlock(), LandSetting.FRAME)){
                        event.setCancelled();
                    }
                }
                if(hasPermission(player,event.getBlock(), LandSetting.INTER)){
                    event.setCancelled();
                }
            }

            @EventHandler
            public void onDrop(PlayerDropItemEvent event){
                Player player = event.getPlayer();
                if(hasPermission(player,player, LandSetting.DROP)){
                    event.setCancelled();
                }
            }

            @EventHandler
            public void onDamage(EntityDamageEvent event){
                if(event instanceof EntityDamageByEntityEvent){
                    Entity entity1 = event.getEntity();
                    Entity entity = ((EntityDamageByEntityEvent) event).getDamager();
                    if(entity instanceof Player && entity1 instanceof Player){
                        if(hasPermission((Player) entity,entity.getLocation(), LandSetting.PVP)){
                            event.setCancelled();
                        }
                    }
                    if(entity instanceof Player){
                        if(hasPermission((Player) entity,entity1.getLocation(), LandSetting.DAMAGE_ENTITY)){
                            event.setCancelled();
                        }
                    }
                }
            }

            @EventHandler
            public void onTransfer(PlayerTeleportEvent event){
                Player player = event.getPlayer();
                LandData data = DataTool.getPlayerLandData(event.getTo());
                if(data != null) {
                    if (!data.hasPermission(player.getName(), LandSetting.TRANSFER)) {
                        event.setCancelled();
                    } else {
                        player.sendMessage(language.playerTransferLand.replace("%name%",data.getLandName()));
                    }
                }
            }
        });
        this.registerAPI("landWindowListener",new NukkitListenerAPI(LandMainClass.MAIN_CLASS)).add(new WindowListener());
    }

    public synchronized void invitePlayer(Player master,Player target,LandData data){
        if(!data.getMaster().equalsIgnoreCase(master.getName()) && !data.getMember().keySet().contains(target.getName())) {
            if (!inviteLands.containsKey(target.getName())) {
                inviteLands.put(target.getName(), new LinkedList<>());
            }
            LinkedList<InviteHandle> handles = inviteLands.get(target.getName());
            InviteHandle handle = new InviteHandle(master.getName(), target.getName(), data, 30);
            if (!handles.contains(handle)) {
                target.sendMessage(language.invitePlayerTarget.replace("%p%", master.getName()).replace("%name%", data.getLandName()));
                master.sendMessage(language.invitePlayerMaster
                        .replace("%p%", target.getName()).replace("%name%", data.getLandName()).replace("%time%", "30"));
                handles.add(handle);
            } else {
                master.sendMessage(language.invitePlayerExists.replace("%p%", target.getName()));
            }
        }else{
            master.sendMessage(language.invitePlayerInArray.replace("%p%",target.getName()).replace("%name%",data.getLandName()));
        }
    }


    public LoadMoney getMoney() {
        return money;
    }

    @Override
    public ModuleInfo getModuleInfo() {
        return new ModuleInfo(LandMainClass.MAIN_CLASS,LandModule.class.getName(),"若水",new ModuleVersion(1,0,0));
    }

    public LandList getList(){
        if(landList == null) {
            Map map = playerConfig.getAll();
            LinkedList<LandData> data = new LinkedList<>();
            if (map.containsKey("lands")) {
                List map1 = (List) map.get("lands");
                for (Object o : map1) {
                    if (o instanceof Map) {
                        Map m = (Map) o;
                        data.add(new LandData(
                                m.get("landName").toString(),
                                m.get("master").toString(),
                                Vector.getVectorByMap((Map) m.get("vector")),
                                new MemberSetting((Map) m.get("member")),
                                new PlayerSetting((Map) m.get("defaultSetting")),
                                m.get("joinMessage").toString(),
                                m.get("quitMessage").toString(),
                                DataTool.getPositionByMap((Map) m.get("transfer"))));
                    }
                }
                landList = new LandList(data);
            }else{
                landList = new LandList(new LinkedList<>());
            }
        }
        return landList;
//        SimpleCodecEasyConfig<LandList> config = module.playerData;
//        LinkedHashMap<String,LandList> healths = config.getSimpleConfig();
//        if(!healths.containsKey("lands")){
//            healths.put("lands",new LandList(new LinkedList<>()));
//            config.save();
//        }
//        return config.getSimpleConfig().get("lands");
    }

    public LandConfig getConfig() {
        SimpleCodecEasyConfig<LandConfig> config = module.config;
        LinkedHashMap<String,LandConfig> healths = config.getSimpleConfig();
        if(!healths.containsKey("settings")){
            healths.put("settings",new LandConfig("[领地系统]",10D,
                    50,new LinkedList<>(),5,0));
            config.save();
        }
        return config.getSimpleConfig().get("settings");
    }


    public static LandModule getModule() {
        return module;
    }


    public Language getLanguage(){
        SimpleCodecEasyConfig<Language> config = module.languageConfig;
        LinkedHashMap<String,Language> healths = config.getSimpleConfig();
        if(!healths.containsKey("languages")){
            healths.put("languages",new Language());
            config.save();
        }
        return config.getSimpleConfig().get("languages");
    }


}
