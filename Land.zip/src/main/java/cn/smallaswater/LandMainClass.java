package cn.smallaswater;

import cn.nukkit.plugin.PluginBase;
import cn.smallaswater.module.LandModule;
import top.wetabq.easyapi.module.EasyAPIModuleManager;


/**
 * @author 若水
 */
public class LandMainClass extends PluginBase {


    public static LandMainClass MAIN_CLASS;
    @Override
    public void onEnable() {
        MAIN_CLASS = this;
        this.getLogger().info("正在启动领地模块");
        EasyAPIModuleManager.INSTANCE.register(new LandModule());
    }
}
