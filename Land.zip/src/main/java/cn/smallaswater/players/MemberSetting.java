package cn.smallaswater.players;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author 若水
 */
public class MemberSetting {

    private LinkedHashMap<String,LinkedHashMap<String,Boolean>> member;

    public MemberSetting(LinkedHashMap<String,LinkedHashMap<String,Boolean>> member){
        this.member = member;
    }

    public MemberSetting(Map map){
        LinkedHashMap<String,LinkedHashMap<String,Boolean>> maps = new LinkedHashMap<>();
        LinkedHashMap<String,Boolean> map1;
        for(Object o:map.keySet()){
            map1 = new LinkedHashMap<>();
            Map map2 = (Map) map.get(o);
            for(Object o1:map2.keySet()){
                map1.put(o1.toString(), (Boolean) map2.get(o1));
            }
            maps.put(o.toString(),map1);
        }
        this.member = maps;
    }

    public Set<String> keySet(){
        return member.keySet();
    }


    public boolean containsKey(String name){
        return member.containsKey(name);
    }

    public void put(String name,PlayerSetting playerSetting){
        member.put(name,playerSetting.getSettings());
    }

    public void remove(String name){
        member.remove(name);
    }

    public PlayerSetting get(String name){
        if (member.containsKey(name)) {
            return new PlayerSetting(member.get(name));
        }
        return null;
    }

    public LinkedHashMap<String, LinkedHashMap<String, Boolean>> getMember() {
        return member;
    }
}
