package cn.smallaswater.players;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author 若水
 */
public class PlayerSetting {

    private LinkedHashMap<String,Boolean> settings;


    public PlayerSetting(LinkedHashMap<String,Boolean> settings){
       this.settings = settings;
    }

    public PlayerSetting(Map map){
        LinkedHashMap<String,Boolean> map1 = new LinkedHashMap<>();
        for(Object s:map.keySet()){
            map1.put(s.toString(), (Boolean) map.get(s));
        }
        this.settings = map1;
    }


    public static PlayerSetting getDefaultSetting(){
        PlayerSetting setting = new PlayerSetting(new LinkedHashMap<>());
        for (LandSetting s:LandSetting.values()){
            setting.settings.put(s.name,false);
        }
        return setting;
    }

    public static PlayerSetting getPlayerDefaultSetting(){
        PlayerSetting setting = new PlayerSetting(new LinkedHashMap<>());
        for (LandSetting s:LandSetting.values()){
            setting.settings.put(s.name,true);
        }
        return setting;
    }

    public LinkedHashMap<String, Boolean> getSettings() {
        return settings;
    }

    public boolean getSetting(String setting){
        if(settings.containsKey(setting)) {
            return settings.get(setting);
        }
        return true;
    }

    public void setSetting(String setting,boolean value) {
        this.settings.put(setting,value);
    }



}
