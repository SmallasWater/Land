package cn.smallaswater.players;

public enum  LandSetting {
    /**锁箱子 玩家移动 玩家传送 锁熔炉 锁放置 锁破坏,锁 PVP 锁伤害生物,锁丢弃，锁拾取*/
    LOCK_CHEST("使用箱子"),MOVE("进入领地"),TRANSFER("传送领地"),FRAME("使用熔炉"),
    PLACE("放置方块"),BREAK("破坏方块"),PVP("PVP"),DAMAGE_ENTITY("伤害生物"),
    DROP("丢弃物品"),INTER("交互其他可交互物品");

    protected String name;
    LandSetting(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }



}
