package cn.smallaswater.utils;

import cn.nukkit.Server;
import cn.nukkit.level.Level;
import cn.nukkit.level.Position;
import cn.nukkit.math.Vector3;
import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.module.LandModule;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

public class DataTool {

    /**
     * 判断是否存在区域重复
     * */
    public static String checkOverlap(Vector vector){
        vector.sort();
        for(LandData overlap: LandModule.getModule().getList().getData()){
            if(overlap.getVector().getLevel().getFolderName().equals(vector.getLevel().getFolderName())){
                if(vector.getStartX() <= overlap.getVector().getEndX()
                        && vector.getEndX() >= overlap.getVector().getStartX() &&
                        vector.getStartY() <= overlap.getVector().getEndY()
                        && vector.getEndY() >= overlap.getVector().getStartY() &&
                        vector.getStartZ() <= overlap.getVector().getEndZ()
                        && vector.getEndZ() >= overlap.getVector().getStartZ()){
                    return overlap.getLandName();
                }
            }
        }
        return null;
    }
    /**
     * 获取领地价值
     * */
    public static double getLandMoney(Vector vector){
        vector.sort();
        double i = 0;
        int x,y,z;
        for(x = vector.getStartX();x <= vector.getEndX();x++){
            for(y = vector.getStartY();y <= vector.getEndY();y++){
                for(z = vector.getStartZ();z <= vector.getEndZ();z++){
                    i+=1;
                }
            }
        }
        return i * LandModule.getModule().getConfig().getLandMoney();
    }

    public static double getGettingMoney(LandData data){
        double m = LandModule.getModule().getConfig().getSellMoney();
        if(m != 0){
            m = DataTool.getLandMoney(data.getVector()) - (DataTool.getLandMoney(data.getVector()) *(((double) LandModule.getModule().getConfig().getSellMoney()) / 100));
        }else{
            m = DataTool.getLandMoney(data.getVector());
        }
        return m;
    }

    public static Position getPositionByMap(Map transfer) {
        String levelName = (String) transfer.get("level");
        Level level = Server.getInstance().getLevelByName(levelName);
        return Position.fromObject(new Vector3((double)transfer.get("x"),(double) transfer.get("y"), (double)transfer.get("z")),level);
    }

    public static LinkedHashMap<String,Object> getMapByTransfer(Position position){
        LinkedHashMap<String,Object> obj = new LinkedHashMap<>();
        obj.put("x",position.x);
        obj.put("y",position.y);
        obj.put("z",position.z);
        obj.put("level",position.level.getFolderName());
        return obj;
    }

    public static LandData getPlayerLandData(Position position){
        String name = getPlayerTouchArea(position);
        return LandModule.getModule().getList().getLandDataByName(name);
    }

    /** 获取点击位置是否在领地*/
    public static String getPlayerTouchArea(Position position){
        if(LandModule.getModule().getList().getData().size() > 0) {
            for (LandData areaClass : LandModule.getModule().getList().getData()) {
                Vector vector = areaClass.getVector().clone();
                vector.sort();
                if (position.level.getFolderName().equals(vector.getLevel().getFolderName())
                        && vector.getStartX() <= position.getFloorX() && vector.getEndX() >= position.getFloorX()
                        && vector.getStartY() <= position.getFloorY() && vector.getEndY() >= position.getFloorY()
                        && vector.getStartZ() <= position.getFloorZ() && vector.getEndZ() >= position.getFloorZ()) {
                    return areaClass.getLandName();
                }
            }
        }
        return null;
    }

    /**
     * 获取玩家的领地
     * */
    public static LinkedList<LandData> getLands(String playerName){
        LinkedList<LandData> dataList = new LinkedList<>();
        for(LandData data:LandModule.getModule().getList().getData()){
            if(data.getMaster().equalsIgnoreCase(playerName) || data.getMember().containsKey(playerName)){
                dataList.add(data);
            }
        }
        return dataList;
    }



    /**
     * 获取传送点
     * */
    public static Position getDefaultPosition(Position pos1, Position pos2) {
        double y;
        if(pos1.getY() >= pos2.getY()){
            y = pos1.getY();
        }else{
            y = pos2.getY();
        }
        double x = 0;
        if((pos1.getX() + pos2.getX()) != 0){
            x = (pos1.getX() + pos2.getX()) / 2;
        }
        return pos1.setComponents(x,y,pos1.getZ());

    }
    public static Position getDefaultPosition(Vector vector){
        return getDefaultPosition(vector.getPos1(),vector.getPos2());
    }
}
