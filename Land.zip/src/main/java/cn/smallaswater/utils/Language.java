package cn.smallaswater.utils;

/**
 * @author 若水
 * 自定义语言文件
 */
public class Language {

    public String playerJoinMessage = "你进入了 %n% 领地 领主: %master% \n 成员: %member%";
    public String playerQuitMessage = "你离开了 %n% 领地 领主: %master% \n 成员: %member%";
    public String playerSetPos1 = "已设置领地第一点 坐标 %pos% 点击另一点设置领地第二点";
    public String playerSetPos2ErrorLevel = "两点不在同一个世界 请重新选择";
    public String playerSetPos2Error = "请先设置第一点";
    public String createNotHavePos = "请先圈地";
    public String createNotHavePos2 = "请先设置第二点";
    public String playerQuitLandMessageTarget = "你退出了 %name% 领地..";
    public String playerQuitLandMessageMaster = "玩家 %p% 退出了 %name% 领地..";
    public String playerJoinLandMessageTarget = "你加入了 %name% 领地..";
    public String playerJoinLandMessageMaster = "玩家 %p% 加入了 %name% 领地..";
    public String position = "x: %x% y: %y% z: %z% level: %level%";
    public String playerSetPos2 = "已设置领地第二点 坐标 %pos%  当前领地价格为 %money% \n如果你的金钱充足 输/land create <名称>创建";
    public String playerBuyLandSuccess = "成功购买领地 %name% 花费 %money%";
    public String playerBuyLandError = "购买领地失败，，你没有足够的金钱";
    public String playerBuyLandErrorLandExists = "领地 %name% 已经存在";
    public String playerBuyLandErrorLandInArray = "与领地 %name%存在冲突 请重新选择";
    public String playerLandMax = "领地已经到达上限啦.. 上限 %count%";
    public String playerTransferLand = "你传送到了 %name% 领地";
    public String landButtonText = "领地: %name% 身份: %p%\n点击查看详情";
    public String master = "(领主)";
    public String member = "(成员)";
    public String other = "(访客)";
    public String notHaveLand = "你还没有领地呢...快去创建一个吧";
    public String landSettingMessage = "领地名称: %name% \n\n领主: %master% \n\n成员: %member%\n\n领地范围: \n%pos%\n\n所在地图: %level%";
    public String pos = "x: %x1% -> %x2% y: %y1% -> %y2% z: %z1% -> %z2%";
    public String quitLandButton = "离开领地";
    public String sellLandButton = "出售领地 ( - %c% ％)";
    public String transferButton = "传送到领地";
    public String giveLandButton = "转让领地";
    public String setLandButton = "领地设置";
    public String choseCanSell = "你确定要出售这个领地吗 当前出售价格 %money% ( - %c% ％)";
    public String choseQuitLand = "你确定要退出这个领地吗?";
    public String labelText = "权限设置对象: %p%";
    public String inviteButton = "邀请玩家";
    public String kickButton = "踢出玩家";
    public String kickLandMessage = "你被 %p% 踢出了 %name% 领地";
    public String sellLandMessage = "你成功出售 %name% 领地 获得 %money%";
    public String setPlayerButton = "玩家领地权限设置";
    public String setOtherButton = "访客领地权限设置";
    public String kickText = "你确定要将玩家 %p% 移除领地吗?";
    public String giveText = "你确定要将领地 %n% 转让给玩家 %p%吗?";
    public String acceptMessageMaster = "玩家 %n% 接受了你的 %name% 领地邀请..";
    public String acceptErrorMaxMaster = "玩家 %n% 的领地已经到达上限 无法加入 %name%领地";
    public String acceptErrorMaxTarget = "你的的领地已经到达上限啦..无法加入%n%的 %name%领地";
    public String acceptMessageMember = "你加入了 %n% 的%name%领地...";
    public String denyMessageMaster = "玩家 %n% 拒绝了你的 %name% 领地邀请..";
    public String denyMessageMember = "你拒绝了 %n% 的领地邀请...";
    public String notHaveInvite = "你没有任何领地邀请";
    public String notHaveTargetInvite = "你没有 %p% 的领地邀请..";
    public String inviteList = ">>========邀请列表=======<<\n%list%";
    public String listValue = " %p% 邀请你加入 %name% 领地 (输/land accept <%p%> 同意邀请)";
    public String notHavePermission = "$title% 你没有操作权限...";
    public String choseTrue = "确定";
    public String choseFalse = "取消";
    public String saveSetting = "%p% 权限设置已保存..";
    public String invitePlayerMaster = "成功向 %p% 发送了加入 %name% 领地邀请 (有效时间 %time% 秒)";
    public String invitePlayerTarget = "%p% 向你发送了 %name% 领地邀请\n/land accept <%p%> 同意领地邀请\n/land deny <%p%> 拒绝邀请";
    public String invitePlayerExists = "你已经邀请了 %p% 啦...";
    public String invitePlayerInArray = "%p% 已经是 %name% 的成员啦.";
    public String dataNotExists = "%name% 领地不存在啦...";
    public String playerOffonline = "%p% 不在线~~";
    public String givePlayerLandTarget = "%p% 将 %name% 领地赠送给你啦~";
    public String givePlayerLandMaster = "你将 %name% 领地赠送给了 %p%~";


}
