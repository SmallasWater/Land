package cn.smallaswater.windows;

import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerFormRespondedEvent;
import cn.nukkit.form.window.FormWindowCustom;
import cn.nukkit.form.window.FormWindowModal;
import cn.nukkit.form.window.FormWindowSimple;
import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.players.LandSetting;
import cn.smallaswater.players.PlayerSetting;
import cn.smallaswater.utils.DataTool;
import cn.smallaswater.utils.Language;

import java.util.LinkedHashMap;

/**
 * @author 若水
 */
public class WindowListener implements Listener {

    private LinkedHashMap<Player,Integer> type = new LinkedHashMap<>();


    @EventHandler
    public void onWindow(PlayerFormRespondedEvent event){
        if (event.getResponse() != null) {
            Language language = LandModule.getModule().getLanguage();
            Player p = event.getPlayer();
            FormWindowSimple simple;
            FormWindowCustom custom;
            FormWindowModal modal;
            int formId = event.getFormID();
            if(formId == CreateWindow.MENU){
                if(!event.wasClosed()){
                    if(event.getWindow() instanceof FormWindowSimple){
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().getList().getData().get(simple.getResponse().getClickedButtonId());
                        if(data != null){
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            LandModule.getModule().clickData.put(p,data);
                            CreateWindow.sendSettingLandMenu(p);
                            return;
                        }
                    }
                }
            }
            if(formId == CreateWindow.SETTING){
                if(!event.wasClosed()){
                    if(event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if (data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            int id = simple.getResponse().getClickedButtonId();
                            if(id == 0){
                                if(!data.hasPermission(p.getName(), LandSetting.TRANSFER)){
                                    p.sendMessage(LandModule.getModule().getLanguage().notHavePermission.replace("%title%",LandModule.getModule().getConfig().getTitle()));
                                    return;
                                }else{
                                    p.teleport(data.getTransfer());
                                    return;
                                }
                            }
                            if (data.getMaster().equalsIgnoreCase(p.getName())){
                                if(id == 1){
                                    CreateWindow.sendSetLandMenu(p);
                                    return;
                                }
                            }else{
                                if(id == 1){
                                    CreateWindow.sendQuitOrSellMenu(p);
                                    return;
                                }
                            }
                        }

                    }
                }else{
                    CreateWindow.sendMenu(p);

                }

            }
            if(formId == CreateWindow.CHOSE){
                if(!event.wasClosed()){
                    if(event.getWindow() instanceof FormWindowModal) {
                        modal = (FormWindowModal) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if (data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            if(data.getMaster().equalsIgnoreCase(p.getName())){
                                if(modal.getResponse().getClickedButtonText().equalsIgnoreCase(language.choseTrue)){
                                    double get = DataTool.getGettingMoney(data);
                                    LandModule.getModule().getMoney().addMoney(p,get);
                                    for(String mode:data.getMember().keySet()){
                                        Player player = Server.getInstance().getPlayer(mode);
                                        if(player != null){
                                            player.sendMessage(language.kickLandMessage.replace("%p%",p.getName()).replace("%name%",data.getLandName()));
                                        }
                                        data.removeMember(mode);
                                    }
                                    p.sendMessage(language.sellLandMessage.replace("%name%",data.getLandName()).replace("%money%",get+""));
                                    LandModule.getModule().getList().remove(data);
                                    LandModule.getModule().saveList();
                                }
                            }else{
                                if(modal.getResponse().getClickedButtonText().equalsIgnoreCase(language.choseTrue)){
                                    data.removeMember(p.getName());
                                }
                            }
                        }
                    }
                }
            }
            if(formId == CreateWindow.LIST){
                if(!event.wasClosed()){
                    if(event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().getList().getData().get(simple.getResponse().getClickedButtonId());
                        if(data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            LandModule.getModule().clickData.put(p,data);
                            CreateWindow.sendSettingLandMenu(p);
                        }
                    }
                }
            }
            if(formId == CreateWindow.SETTING_LAND){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowCustom) {
                        custom = (FormWindowCustom) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        String playerName = LandModule.getModule().clickPlayer.get(p);
                        LandModule.getModule().clickPlayer.remove(p);
                        int i = 1;
                        if (data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            for (LandSetting setting : LandSetting.values()) {
                                if (playerName != null) {
                                    data.setPlayerSetting(playerName, setting, custom.getResponse().getToggleResponse(i));
                                } else {
                                    data.setDefaultSetting(setting.getName(), custom.getResponse().getToggleResponse(i));
                                }
                                i++;
                            }
                            if (playerName != null) {
                                p.sendMessage(language.saveSetting.replace("%p%", playerName));
                            } else {
                                p.sendMessage(language.saveSetting.replace("%p%", language.other));
                            }
                        }
                    }
                }
            }
            if(formId == CreateWindow.MEMBERS){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        int type = this.type.get(p);
                        this.type.remove(p);
                        String s = simple.getResponse().getClickedButton().getText();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if(data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            if(data.getMember().keySet().contains(s)) {
                                if (type == 0) {
                                    //踢出玩家
                                    LandModule.getModule().clickPlayer.put(p,s);
                                    CreateWindow.sendKickMenu(p,s);
                                } else if (type == 1) {
                                    //设置权限
                                    LandModule.getModule().clickPlayer.put(p,s);
                                    CreateWindow.sendLandSettingMenu(p,s);
                                }
                            }
                        }
                    }
                }
            }
            if(formId == CreateWindow.SET_LAND){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if(data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 0){
                                CreateWindow.sendInvitePlayerMenu(p);
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 1){
                                type.put(p,0);
                                CreateWindow.sendMemberList(p);
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 2){
                                type.put(p,1);
                                CreateWindow.sendMemberList(p);
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 3){
                                CreateWindow.sendLandSettingMenu(p);
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 4){
                                CreateWindow.sendQuitOrSellMenu(p);
                                return;
                            }
                            if(simple.getResponse().getClickedButtonId() == 5){
                                CreateWindow.sendInvitePlayerMenu(p);
                                type.put(p,2);
                                LandModule.getModule().clickPlayer.remove(p);
                                return;
                            }
                        }
                    }
                }
            }
            if(formId == CreateWindow.KICK_MENU){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowModal) {
                        modal = (FormWindowModal) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        String player = LandModule.getModule().clickPlayer.get(p);
                        LandModule.getModule().clickPlayer.remove(p);
                        if (data != null) {
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }
                            if(player != null) {
                                if (modal.getResponse().getClickedButtonText().equalsIgnoreCase(language.choseTrue)) {
                                    data.removeMember(player);
                                }
                                Player player1 = Server.getInstance().getPlayer(player);
                                if (player1 != null) {
                                    player1.sendMessage(language.kickLandMessage.replace("%p%", p.getName()).replace("%name%", data.getLandName()));
                                }
                            }
                        }
                    }
                }
            }
            if(formId == CreateWindow.GIVE_MENU){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if (data != null) {
                            if (!LandModule.getModule().getList().contains(data)) {
                                p.sendMessage(language.dataNotExists.replace("%name%", data.getLandName()));
                                return;
                            }
                            String player = simple.getResponse().getClickedButton().getText();
                            Player player1 = Server.getInstance().getPlayer(player);
                            if(data.getMember().keySet().contains(player)){
                                data.removeMember(player);
                            }
                            data.setMaster(player);
                            if(player1 != null){
                                player1.sendMessage(language.givePlayerLandTarget
                                        .replace("%p%",p.getName()).replace("%name%",data.getLandName()));
                            }
                            p.sendMessage(language.givePlayerLandMaster
                                    .replace("%p%",p.getName()).replace("%name%",data.getLandName()));

                        }

                    }
                }
            }
            if(formId == CreateWindow.INVITE_PLAYER){
                if(!event.wasClosed()) {
                    if (event.getWindow() instanceof FormWindowSimple) {
                        simple = (FormWindowSimple) event.getWindow();
                        LandData data = LandModule.getModule().clickData.get(p);
                        if(data != null) {
                            String player = simple.getResponse().getClickedButton().getText();
                            Player player1 = Server.getInstance().getPlayer(player);
                            if(type.containsKey(p)){
                                if(type.get(p) == 2){
                                    if(player1 != null){
                                        LandModule.getModule().clickPlayer.put(p,player1.getName());
                                        CreateWindow.sendGiveLandMenu(p,player1.getName());
                                        return;
                                    }else{
                                        p.sendMessage(language.playerOffonline.replace("%p%",player));
                                    }
                                    type.remove(p);
                                    return;
                                }
                            }
                            if(!LandModule.getModule().getList().contains(data)){
                                p.sendMessage(language.dataNotExists.replace("%name%",data.getLandName()));
                                return;
                            }

                            if(player1 != null){
                                LandModule.getModule().invitePlayer(p,player1,data);
                            }else{
                                p.sendMessage(language.playerOffonline.replace("%p%",player));
                            }
                        }
                    }
                }
            }
        }
    }



}
