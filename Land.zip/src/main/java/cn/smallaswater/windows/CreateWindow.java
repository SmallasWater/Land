package cn.smallaswater.windows;

import cn.nukkit.Player;
import cn.nukkit.Server;
import cn.nukkit.form.element.ElementButton;
import cn.nukkit.form.element.ElementButtonImageData;
import cn.nukkit.form.element.ElementLabel;
import cn.nukkit.form.element.ElementToggle;
import cn.nukkit.form.window.FormWindowCustom;
import cn.nukkit.form.window.FormWindowModal;
import cn.nukkit.form.window.FormWindowSimple;
import cn.smallaswater.land.utils.LandData;
import cn.smallaswater.module.LandModule;
import cn.smallaswater.players.LandSetting;
import cn.smallaswater.players.PlayerSetting;
import cn.smallaswater.utils.DataTool;
import cn.smallaswater.utils.Language;

/**
 * @author 若水
 */
public class CreateWindow {

    static int MENU = 0x125Ac01;
    static int SETTING = 0x125Ac02;
    static int CHOSE = 0x125Ac03;
    static int LIST = 0x125Ac04;
    static int SETTING_LAND = 0x125Ac04;
    static int MEMBERS = 0x125Ac05;
    static int SET_LAND = 0x125Ac06;
    static int KICK_MENU = 0x125Ac07;
    static int GIVE_MENU = 0x125Ac08;
    static int INVITE_PLAYER = 0x125Ac09;

    /**
     * 玩家领地菜单
     * */
    public static void sendMenu(Player player){
        FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(),"");
        for(LandData data: DataTool.getLands(player.getName())){
            simple.addButton(getButton(player,data));
        }
        if(simple.getButtons().size() == 0){
            simple.setContent(LandModule.getModule().getLanguage().notHaveLand);
        }
        player.showFormWindow(simple,MENU);
    }

    /**
     * 显示玩家的下一步菜单 需设置 clickdata
     * */
    public static void sendSettingLandMenu(Player player){
        LandData data =  LandModule.getModule().clickData.get(player);
        if(data != null) {
            FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(), "");
            simple.setContent(LandModule.getModule().getLanguage()
                    .landSettingMessage
                    .replace("%name%",data.getLandName())
                    .replace("%master%",data.getMaster())
                    .replace("%member%",data.getMember().keySet().toString())
                    .replace("%pos%",
                            LandModule.getModule().getLanguage().pos
                                    .replace("%x1%",data.getVector().getStartX()+"")
                                    .replace("%x2%",data.getVector().getEndX()+"")
                                    .replace("%y1%",data.getVector().getStartY()+"")
                                    .replace("%y2%",data.getVector().getEndY()+"")
                                    .replace("%z1%",data.getVector().getStartZ()+"")
                                    .replace("%z2%",data.getVector().getEndZ()+""))
                    .replace("%level%",data.getVector().getLevel().getFolderName()));
            if(data.getMember().containsKey(player.getName())){
                simple.addButton(new ElementButton(LandModule.getModule().getLanguage().transferButton));
                simple.addButton(new ElementButton(LandModule.getModule().getLanguage().quitLandButton));
            }else{
                if(data.getMaster().equalsIgnoreCase(player.getName())){
                    simple.addButton(new ElementButton(LandModule.getModule().getLanguage().transferButton));
                    simple.addButton(new ElementButton(LandModule.getModule().getLanguage().setLandButton));
                }else{
                    simple.addButton(new ElementButton(LandModule.getModule().getLanguage().transferButton));
                }
            }
            player.showFormWindow(simple,SETTING);
        }
    }

    private static ElementButton getButton(Player player,LandData data){
        String master = LandModule.getModule().getLanguage().master;
        if(data.getMember().containsKey(player.getName())){
            master = LandModule.getModule().getLanguage().member;
        }else if(!data.getMaster().equalsIgnoreCase(player.getName())){
            master = LandModule.getModule().getLanguage().other;
        } String s = LandModule.getModule().getLanguage()
                .landButtonText.replace("%name%",data.getLandName()).replace("%p%",master);
        return new ElementButton(s,new ElementButtonImageData("path","textures/ui/icon_recipe_nature"));
    }

    /**
     * 显示所有领地列表
     * */
    public static void sendLandDataList(Player player){
        FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(), "");
        for(LandData data:LandModule.getModule().getList().getData()){
            simple.addButton(getButton(player,data));
        }
        player.showFormWindow(simple,LIST);
    }

    /**
     * 设置领地权限
     * */
    public static void sendLandSettingMenu(Player player){
        sendLandSettingMenu(player,null);
    }

    public static void sendLandSettingMenu(Player player,String playerName){
        Language language = LandModule.getModule().getLanguage();
        LandData data =  LandModule.getModule().clickData.get(player);
        if(data != null) {
            FormWindowCustom custom = new FormWindowCustom(LandModule.getModule().getConfig().getTitle());
            custom.addElement(new ElementLabel(language.labelText.replace("%p%",(playerName!=null?playerName:language.other))));
            for(LandSetting setting: LandSetting.values()){
                custom.addElement(new ElementToggle(setting.getName(),data.hasPermission(playerName,setting)));
            }
            player.showFormWindow(custom,SETTING_LAND);
        }
    }

    /**
     * 显示领地设置
     * */
    public static void sendSetLandMenu(Player player){
        Language language = LandModule.getModule().getLanguage();
        FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(), "");
        simple.addButton(new ElementButton(language.inviteButton,new ElementButtonImageData("path","textures/ui/invite_base")));
        simple.addButton(new ElementButton(language.kickButton,new ElementButtonImageData("path","textures/ui/realms_red_x")));
        simple.addButton(new ElementButton(language.setPlayerButton,new ElementButtonImageData("path","textures/ui/recipe_book_icon")));
        simple.addButton(new ElementButton(language.setOtherButton,new ElementButtonImageData("path","textures/ui/recipe_book_icon")));
        simple.addButton(new ElementButton(LandModule.getModule().getLanguage().sellLandButton.replace("%c%",
                LandModule.getModule().getConfig().getSellMoney()+"")));
        simple.addButton(new ElementButton(LandModule.getModule().getLanguage().giveLandButton));
        player.showFormWindow(simple,SET_LAND);
    }

    /**
     * 显示成员列表
     * */
    public static void sendMemberList(Player player){
        LandData data =  LandModule.getModule().clickData.get(player);
        if(data != null) {
            FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(), "");
            for(String member:data.getMember().keySet()){
                simple.addButton(new ElementButton(member,new ElementButtonImageData("path","textures/ui/Friend2")));
            }
            player.showFormWindow(simple,MEMBERS);
        }
    }

    /**
     * 选择踢出玩家
     * */
    public static void sendKickMenu(Player player,String name){
        Language language = LandModule.getModule().getLanguage();
        FormWindowModal modal = new FormWindowModal(LandModule.getModule().getConfig().getTitle(),"","确认","取消");
        modal.setContent(language.kickText.replace("%p%",name));
        player.showFormWindow(modal,KICK_MENU);
    }
    /**
     * 邀请玩家*/
    public static void sendInvitePlayerMenu(Player player){
        FormWindowSimple simple = new FormWindowSimple(LandModule.getModule().getConfig().getTitle(), "");
        for(Player player1: Server.getInstance().getOnlinePlayers().values()) {
            if (!player1.getName().equalsIgnoreCase(player.getName())) {
                simple.addButton(new ElementButton(player1.getName(), new ElementButtonImageData("path", "textures/ui/Friend2")));
            }
        }
        player.showFormWindow(simple,INVITE_PLAYER);
    }

    /**
     * 选择转让玩家
     * */
    public static void sendGiveLandMenu(Player player,String name){
        Language language = LandModule.getModule().getLanguage();
        FormWindowModal modal = new FormWindowModal(LandModule.getModule().getConfig().getTitle(),"",language.choseTrue,language.choseFalse);
        modal.setContent(language.giveText.replace("%p%",name));
        player.showFormWindow(modal,GIVE_MENU);
    }

    /**
     * 选择退出领地或出售
     * */
    public static void sendQuitOrSellMenu(Player player){
        Language language = LandModule.getModule().getLanguage();
        FormWindowModal modal = new FormWindowModal(LandModule.getModule().getConfig().getTitle(),"",language.choseTrue,language.choseFalse);
        LandData data =  LandModule.getModule().clickData.get(player);
        if(data != null) {
            if(data.getMaster().equalsIgnoreCase(player.getName())){
                double m = DataTool.getGettingMoney(data);
                modal.setContent(language.choseCanSell
                        .replace("%money%",String.format("%.2f",m))
                        .replace("%c%",LandModule.getModule().getConfig().getSellMoney()+"")
                        .replace("%name%",data.getLandName()));
            }else{
                modal.setContent(language.choseQuitLand.replace("%name%",data.getLandName()));
            }
            player.showFormWindow(modal,CHOSE);
        }
    }
}
